#Usage colleciing_profile.sh  RUNTIME_SEC WARNYO
#READPROFILE=/tmp/readprofile_ap  
#READPROFILE2=/tmp/readprofile_mjb
READPROFILE3=/tmp/readp/readprofile_2_11_gcc3
#READPROFILE3=/tmp/readprofile_aporig
READPROFILE=/tmp/readprofile-andyp-2.11z
DURATION=$1
WARMUP=$2


#(( STEP = ( $DURATION - $WARMUP )  / 10 ))
(( STEP =  $DURATION - $WARMUP    ))

#READPROFILE=/usr/src/util-linux-2.11z/sys-utils/readprofile
# detective profwatch to see if counter collect is bad
#/home/sapdb/dbt2/scripts/output/analyze/profwatch > /s1/sapdb/profwatch.out 2>&1 &

# allow for warmup time in seconds
# Start profiling, clear stats
echo "Collecting  profile data for run of $DURATION seconds  warmup of $WARMUP "
sleep $WARMUP

echo "clearing profile data"
date
sudo   ${READPROFILE}   -m /boot/System.map -r  

#sudo bash ./setup_profile.sh 2
 

#for I in 1 2 3 4 5 6 7 8 9 10
#do
#echo "Display profile data - Step $I " 


sleep $STEP 


# Print stats and stop profiling

date
echo "Using readprofile: $READPROFILE "
sudo  ${READPROFILE}  -m /boot/System.map -vn | sort -grk3,4  


#done
#sudo bash ./setup_profile.sh

#echo "Using readprofile: $READPROFILE2 "
#sudo  ${READPROFILE2}  -m /boot/System.map -v | sort -grk3,4

echo "Using readprofile: $READPROFILE3 "
sudo  ${READPROFILE3}  -m /boot/System.map -v | sort -grk3,4

