tar cvf /tmp/dbt2_HT.tar  README run_test9.sh sapdb/*.sh  wrap_sets/wrap*  *.sh .run_number
cd output
tar cvf /tmp/dbt2_HT_output.tar  206 210  analyze.sh c4_21rc1dmo c5_64osdl_1A c5_66_2A c5_68dmo c5_68dmoNOHT c5_68Idmo compress_old_runs.sh create_plot_tar.sh doitplot_2A.sh doitplot_68I.sh doitplot.sh footer.html header.html HT_M nc4_21rc1dmo nc5_64osdl_1A nc5_66_2A nc5_68dmo nc5_68dmoNOHT nc5_68Idmo plot_cpus.sh plot_setup plot_vmstat.sh README template_top.html web web_68I web_HT1A web_HT2A web_make_results.sh web_maketitles.sh web_vmstat.sh xfer_results.sh

