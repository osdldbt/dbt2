OUTDIR="/m2/dbt2/datagen"
for TAB in warehouse customer history new_order order_line district item order stock
do
echo " ln -s  ${OUTDIR}/${TAB}.data /tmp/${TAB}.data  "
done
