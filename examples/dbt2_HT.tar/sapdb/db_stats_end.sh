OUTPUT_DIR=$1
SID=DBT2
# record devspace space information after the test
/opt/sapdb/depend/bin/dbmcli -d $SID -u dbm,dbm -uSQL dbt,dbt -c info data > $OUTPUT_DIR/datadev1.txt
/opt/sapdb/depend/bin/dbmcli -d $SID -u dbm,dbm -uSQL dbt,dbt -c info log > $OUTPUT_DIR/logdev1.txt

