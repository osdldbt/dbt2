#!/bin/sh

SID=DBT2

echo "changing data_cache to 10000"
_o=`cat <<EOF |  /opt/sapdb/depend/bin/dbmcli -d $SID -u dbm,dbm 2>&1
param_startsession
param_put DATA_CACHE 10000
param_checkall
param_commitsession
quit
EOF`
_test=`echo $_o | grep ERR`
if ! [ "$_test" = "" ]; then
	echo "set parameters failed"
	exit 1
fi

_o=`cat <<EOF | /opt/sapdb/depend/bin/dbmcli -d $SID -u dbm,dbm 2>&1
util_connect dbm,dbm
backup_start data1 migration
backup_replace data2
backup_replace data3
backup_replace data4
backup_replace data5
backup_replace data6
backup_replace data7
backup_replace data8
backup_replace data9
backup_replace data10
backup_replace data11
backup_start incremental migration
quit
EOF`
_test=`echo $_o | grep ERR`
if ! [ "$_test" = "" ]; then
        echo "backup failed: $_o"
        exit 1
fi
