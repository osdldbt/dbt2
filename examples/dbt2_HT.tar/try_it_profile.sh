OUTPUT_DIR=output/00
# mkdir $OUTPUT_DIR
echo "" > $OUTPUT_DIR/readprofile_2.out


sudo bash ./setup_profile_2.sh 2    >> $OUTPUT_DIR/readprofile_2.out  &  
sleep 5

cd $OUTPUT_DIR
for TIME in 1 2 
do
ls  > /dev/null   2>&1 &
df -k   > /dev/null 2>&1 &
cat /var/log/messages > /dev/null 2>&1 &
sleep 10
done
sudo bash ../../setup_profile_2.sh    >>  readprofile_2.out 

cd -
