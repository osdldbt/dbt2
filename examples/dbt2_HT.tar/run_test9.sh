#!/bin/sh

# run_test.sh
# Supports fixed seeds for 8 or 16 driver cases.  Other driver cases default to variable
#
# This file is released under the terms of the Artistic License.  Please see
# the file LICENSE, included in this package, for details.
#
# Copyright (C) 2002 Mark Wong & Open Source Development Lab, Inc.
#
# 18 october 2002

#Seed Arrays:
declare -a SEED8=( 1677042820 3547905152 1123812500 2994699456 570631428 2441543008 17499604 1888435808 )
declare -a SEED16=( 1881941682 4035168448 1893440230 4046691620 1904988026 4058264040 1916585070 4069885708 1928231362 4081556624 1939926902 4093276788 1951671690 4105046200 1963465726 4116864860 )
Sptr=0  #pointer to SEED arrays
# point to SEED8: ${SEED8[$Sptr]}
# point to SEED16: ${SEED16[$Sptr]}

if [ $# -lt 6 ]; then
	echo "usage: run_test.sh --duration <sec> --sample <sec> -w <warehouses>"
	exit
fi

PROMPT=1

while :
do
	case $# in
	0)
		break
		;;
	esac

	option=$1
	shift

	orig_option=$option
	case $option in
	--*)
		;;
	-*)
		option=-$option
		;;
	esac

	case $option in
	--*=*)
		optarg=`echo $option | sed -e 's/^[^=]*=//'`
		arguments="$arguments $option"
		;;
	--sample | --duration | --wmin | --wmax | --warehouses | --ktd | --ktn | --kto | --ktp | --kts | --ttd | --ttn | --tto | --ttp | --tts | --tpw | --comment | --drivers | --spread | --pmix | --nmix | --smix | --dmix | --omix)
		optarg=$1
		shift
		arguments="$arguments $option=$optarg"
		;;
	esac

	case $option in
	--duration)
		DURATION=$optarg
		;;
	--sample)
		SAMPLE_LENGTH=$optarg
		;;
	--wmin)
		WMIN=$optarg
		;;
	--wmax)
		WMAX=$optarg
		;;
	--warehouses)
		WAREHOUSES=$optarg
		;;
	--ktd)
		KTD=$optarg
		;;
	--ktn)
		KTN=$optarg
		;;
	--kto)
		KTO=$optarg
		;;
	--ktp)
		KTP=$optarg
		;;
	--kts)
		KTS=$optarg
		;;
	--ttd)
		TTD=$optarg
		;;
	--ttn)
		TTN=$optarg
		;;
	--tto)
		TTO=$optarg
		;;
	--ttp)
		TTP=$optarg
		;;
	--tts)
		TTS=$optarg
		;;
	--tpw)
		TPW=$optarg
		;;
	--comment)
		COMMENT=$optarg
		PROMPT=0
		;;
	--drivers)
		DRIVERS=$optarg
		;;
	--spread)
		SPREAD=$optarg
		;;
	--omix)
		OMIX=$optarg
		;;
	--nmix)
		NMIX=$optarg
		;;
	--smix)
		SMIX=$optarg
		;;
	--dmix)
		DMIX=$optarg
		;;
	--pmix)
		PMIX=$optarg
		;;
	esac
done

ITERATION=`expr $DURATION / $SAMPLE_LENGTH`

# determine run number for selecting an output directory
RUN_NUMBER=-1
read RUN_NUMBER < .run_number
if [ $RUN_NUMBER -eq -1 ]; then
	RUN_NUMBER=0
fi
mkdir -p output
mkdir -p output/$RUN_NUMBER
OUTPUT_DIR=output/$RUN_NUMBER
RUN_NUMBER=`expr $RUN_NUMBER + 1`
echo $RUN_NUMBER > .run_number

# Capture a comment.
if [ $PROMPT -eq 1 ]; then
	echo "Enter a short description about this run:"
	read COMMENT
fi
echo "$COMMENT" >> $OUTPUT_DIR/readme.txt
echo >> $OUTPUT_DIR/readme.txt

# start the database
echo "starting the database"
sapdb/start_db.sh

cd $OUTPUT_DIR
~sapdb/dbt2/scripts/sapdb/plan.sh > plan0.out
cat /proc/cpuinfo |grep physical  > cpuinfo0.out
cat /proc/cpuinfo >> cpuinfo0.out
cat /proc/cmdline >   cmdline.out
cat /proc/meminfo >   meminfo0.out
(sleep 2000; cat /proc/meminfo >   meminfo2000sec.out ) &
cd -

#echo "Start collecting  profile data `date` " >   $OUTPUT_DIR/readprofile.out
# sudo bash -x ./setup_profile_2.sh 2    > $OUTPUT_DIR/readprofile_begin.out   2<&1  &  
#READPROFILE=/usr/src/util-linux-2.11z/sys-utils/readprofile
#sudo   ${READPROFILE}   -m /boot/System.map -r  > $OUTPUT_DIR/readprofile_begin.out 

WARMUP=1200
bash ./collect_profile.sh $DURATION $WARMUP  > $OUTPUT_DIR/readprofile.out 2>&1 &

# start system stat gathering
./sysstats.sh --db sapdb --dbname dbt2 --outdir $OUTPUT_DIR --iter $ITERATION --sample $SAMPLE_LENGTH &
sleep 2

echo "Current path is `pwd` "
# start a test run
#CMD="../../../../terminal/driver.jan14_pre_lock -dbname dbt2 -w $WAREHOUSES -l $DURATION"
CMD="/home/sapdb/dbt2/terminal/driver -dbname dbt2 -w $WAREHOUSES -l $DURATION"

# generate the command line argument for the driver depending on the
# flags used

if ! [ -z $KTD ]; then
	CMD="$CMD -ktd $KTD"
fi

if ! [ -z $KTN ]; then
	CMD="$CMD -ktn $KTN"
fi

if ! [ -z $KTO ]; then
	CMD="$CMD -kto $KTO"
fi

if ! [ -z $KTP ]; then
	CMD="$CMD -ktp $KTP"
fi

if ! [ -z $KTS ]; then
	CMD="$CMD -kts $KTS"
fi 

if ! [ -z $TTD ]; then
	CMD="$CMD -ttd $TTD"
fi

if ! [ -z $TTN ]; then
	CMD="$CMD -ttn $TTN"
fi

if ! [ -z $TTO ]; then
	CMD="$CMD -tto $TTO"
fi

if ! [ -z $TTP ]; then
	CMD="$CMD -ttp $TTP"
fi

if ! [ -z $TTS ]; then
	CMD="$CMD -tts $TTS"
fi

if ! [ -z $TPW ]; then
	CMD="$CMD -tpw $TPW"
fi

if ! [ -z $NMIX ]; then
	CMD="$CMD -n $NMIX"
fi

if ! [ -z $PMIX ]; then
	CMD="$CMD -q $PMIX"
fi

if ! [ -z $OMIX ]; then
	CMD="$CMD -r $OMIX"
fi

if ! [ -z $SMIX ]; then
	CMD="$CMD -t $SMIX"
fi

if ! [ -z $DMIX ]; then
	CMD="$CMD -e $DMIX"
fi

# start the driver
cd $OUTPUT_DIR


COUNT=0
while [ $COUNT -lt $DRIVERS ]
do
	COUNT=$(($COUNT+1))
	mkdir -p $COUNT
done

COUNT=0
SMIN=1
(( OFFSET = $WAREHOUSES / $DRIVERS ))
COMMAND="$CMD"
while [ $COUNT -lt $DRIVERS ]
do
        SMAX=$(($SMIN+$SPREAD-1))
	Sptr=$COUNT
        # Assign the SEED
        if [ $DRIVERS -eq 8 ]; then
                CMD="$COMMAND -seed ${SEED8[$Sptr]} "
                else
                if [ $DRIVERS -eq 16 ]; then
                   CMD="$COMMAND -seed ${SEED16[$Sptr]} "
                fi
        #otherwise use default seed 
        fi

	COUNT=$(($COUNT+1))
	cd $COUNT
	echo "$CMD -wmin $SMIN -wmax $SMAX" > driver.out &
	echo >> driver.out &
	$CMD -wmin $SMIN -wmax $SMAX >> driver.out &
	cd -
        #SMIN=$(($SMAX+1))
        SMIN=$((${OFFSET}*$COUNT+1))
	sleep 1
done

echo "sleeping"
sleep $DURATION


#sudo bash -x ../../setup_profile_2.sh    >  readprofile_end.out 
#echo "The time is: `date`"  > readprofile_end.out
#sudo  ${READPROFILE}  -m /boot/System.map -v | sort -grk3,4  >> readprofile_end.out 


# copy the terminal output files to the output directory
echo "running results..."
COUNT=0
while [ $COUNT -lt $DRIVERS ]
do
	COUNT=$(($COUNT+1))
	cd $COUNT
	../../../../tools/results mix.log $SAMPLE_LENGTH . > results.txt
	cd -
done

# analyze the results of mix.log
echo "START" > mix_all.log
cat */mix.log | sort | grep -v START >> mix_all.log
../../../tools/results mix_all.log $SAMPLE_LENGTH . > results.txt
../../sapdb/plan.sh > plan1.out
cat /proc/meminfo >   meminfo1.out

# output the log and data file info
../../sapdb/db_stats_end.sh  $PWD
cp -p /var/opt/sapdb/ind*/wrk/DBT2/knldiag  knldiag.out

echo "run complete"

# stop the database
echo "stopping the database"
../../sapdb/stop_db.sh
cp -p /var/opt/sapdb/ind*/wrk/DBT2/knldiag  knldiag_shutdown.out
