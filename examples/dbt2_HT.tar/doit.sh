echo "Run on 8 way with 4 user tasks active to show Ingo's improvements"
date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_maxcpu4.sh

date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_maxcpu4.sh

date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_maxcpu4.sh

date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_maxcpu4.sh

date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_maxcpu4.sh


exit
 date
echo Run Number `cat .run_number`
wrap_sets/wrap_16x6_DataCache300000.sh

exit
 date
echo Run Number `cat .run_number`
wrap_sets/wrap_16x6_DataCache300000.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_16x6_DataCache300000.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_DataCache300000.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_DataCache300000.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_DataCache300000.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_DataCache300000.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_DataCache300000.sh


exit
 date
echo Run Number `cat .run_number`
wrap_sets/wrap_16x6_DataCache300000.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_16x6_DataCache300000.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_16x6_DataCache300000.sh


exit
 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_DataCache300000_maxcpu4.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_DataCache300000_maxcpu4.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_DataCache300000_maxcpu4.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_DataCache300000_maxcpu4.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2_DataCache300000_maxcpu4.sh

date
echo Run Number `cat .run_number`
wrap_sets/wrap_16x6_DataCache300000_maxcpu4.sh

date
echo Run Number `cat .run_number`
wrap_sets/wrap_16x6_DataCache300000_maxcpu4.sh

date
echo Run Number `cat .run_number`
wrap_sets/wrap_16x6_DataCache300000_maxcpu4.sh

exit
date
echo Run Number `cat .run_number`
wrap_sets/wrap_16x6.sh

date
echo Run Number `cat .run_number`
wrap_sets/wrap_16x6.sh

date
echo Run Number `cat .run_number`
wrap_sets/wrap_16x6.sh

exit

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2.sh

 date
echo Run Number `cat .run_number`
wrap_sets/wrap_8x2.sh



date
echo NEXT Run Number `cat .run_number`

date
echo NEXT Run Number `cat .run_number`

