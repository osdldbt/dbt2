#!/bin/sh

# sysstats.sh
#
# This file is released under the terms of the Artistic License.  Please see
# the file LICENSE, included in this package, for details.
#
# Copyright (C) 2002 Mark Wong & Open Source Development Lab, Inc.
#
# 17 october 2002
SAR=/home/sapdb/sysstat/lib/sa/sadc
RUNTIME=20  #minutes to  collect metric

if [ $# -lt 1 ]; then
    echo "usage: sysstats.sh --db <database> --dbname <database_name> --outdir <output_dir> --iter <iterations> -sample <sample_length>"
    echo "	<output_dir> will be created if it doesn't exist"
    exit
fi

COUNTER=0

while :
do
	case $# in
	0)
		break
		;;
	esac

	option=$1
	shift

	orig_option=$option
	case $option in
	--*)
		;;
	-*)
		option=-$option
		;;
	esac

	case $option in
	--*=*)
		optarg=`echo $option | sed -e 's/^[^=]*=//'`
		arguments="$arguments $option"
		;;
	--db | --dbname | --outdir | --iter | --sample)
		optarg=$1
		shift
		arguments="$arguments $option=$optarg"
		;;
	esac

	case $option in
	--db)
		DATABASE=$optarg
		;;
	--dbname)
		DATABASE_NAME=$optarg
		;;
	--outdir)
		OUTPUT_DIR=$optarg
		;;
	--iter)
		ITERATIONS=$optarg
		;;
	--sample)
		SAMPLE_LENGTH=$optarg
		;;
	esac
done

if [ -z $DATABASE ]; then
	echo "use --db"
	exit
fi
if [ -z $DATABASE_NAME ]; then
	echo "use --dbname"
	exit
fi
if [ -z $OUTPUT_DIR ]; then
	echo "use --outdir"
	exit
fi
if [ -z $ITERATIONS ]; then
	echo "use --iter"
	exit
fi
if [ -z $SAMPLE_LENGTH ]; then
	echo "use --sample"
	exit
fi

# create the output directory in case it doesn't exist
mkdir -p $OUTPUT_DIR

# create a readme with general information
date >> $OUTPUT_DIR/readme.txt

uname -a >> $OUTPUT_DIR/readme.txt
echo "sample length: $SAMPLE_LENGTH seconds" >> $OUTPUT_DIR/readme.txt
echo "iterations: $ITERATIONS" >> $OUTPUT_DIR/readme.txt

# capture kernel settings
/sbin/sysctl -a | sort > $OUTPUT_DIR/proc.out

read RN < .run_number
CURRENT_NUM=`expr $RN - 1`
PREV_NUM=`expr $RN - 2`

CURRENT_DIR=output/$CURRENT_NUM
PREV_DIR=output/$PREV_NUM

echo >> $OUTPUT_DIR/readme.txt
echo "Changed Linux kernel parameters:" >> $OUTPUT_DIR/readme.txt
diff -U 0 $CURRENT_DIR/proc.out $PREV_DIR/proc.out >> $OUTPUT_DIR/readme.txt
echo >> $OUTPUT_DIR/readme.txt
echo "swappiness setting: `cat /proc/sys/vm/swappiness` " >> $OUTPUT_DIR/readme.txt

echo "starting system data collection"

# collect cpu data per cpu
#sar -u -U ALL $SAMPLE_LENGTH $ITERATIONS >> $OUTPUT_DIR/cpu.out &
#sar -o $OUTPUT_DIR/sar_raw.out $SAMPLE_LENGTH $ITERATIONS &
${SAR} $SAMPLE_LENGTH $ITERATIONS  $OUTPUT_DIR/sar_raw.out &

# collect vmstat 
#vmstat $SAMPLE_LENGTH $ITERATIONS >> $OUTPUT_DIR/vmstat.out &
# Use non-shared version local to sapdb, version  procps-3.1.6

 /home/sapdb/usr/bin/vmstat $SAMPLE_LENGTH $ITERATIONS >> $OUTPUT_DIR/vmstat.out &

# collect network traffic data per device
#sar -n DEV $SAMPLE_LENGTH $ITERATIONS >> $OUTPUT_DIR/network.out &

# collect i/o data per logical device
#iostat -d -x $SAMPLE_LENGTH $ITERATIONS >> $OUTPUT_DIR/iostat.out &
#Select the right iostat depending on the OS release number 2.4 or 2.5
# Also need another version from 2.5.64 on

VERSION=`uname -r | awk -F "." '{print $2}'`
VERSIONSUB=`uname -r | awk -F "." '{print $3}' | awk -F "-" '{print $1}' `


if [ $VERSION -eq 5 ]
then
  if [ $VERSIONSUB -lt 64 ]
  then
  iostat2.5 -x $SAMPLE_LENGTH $ITERATIONS  >> $OUTPUT_DIR/iostat2.5_x.out &
  else
  iostat2.5.64 -x $SAMPLE_LENGTH $ITERATIONS  >> $OUTPUT_DIR/iostat2.5_x.out &
  fi
else
iostat -d $SAMPLE_LENGTH $ITERATIONS >> $OUTPUT_DIR/iostat.out &
fi

# collect database statistics
echo "starting database statistics gathering"
if [ $DATABASE = "sapdb" ]; then
	sapdb/db_stats.sh DBT2 $OUTPUT_DIR $ITERATIONS $SAMPLE_LENGTH
fi


# from the old version
#echo "data gathering complete, transforming data..."
#grep all $OUTPUT_DIR/cpu.out | grep -v Average | awk '{ print NR","$4","$5","$6 }' > $OUTPUT_DIR/cpu_all.csv


echo "data gathering complete, transforming data..."
./transform_sar.sh $OUTPUT_DIR/sar_raw.out $SAMPLE_LENGTH $OUTPUT_DIR

