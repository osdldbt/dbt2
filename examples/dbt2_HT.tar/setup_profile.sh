# Run sudo ./setup_orofile <profile shift> to start profiling and clear stats
# Run sudo ./setup_profile.sh to stop profiling and print stats to stdout


# Starting - clear profile data
clearprof () {
/usr/sbin/readprofile -m /boot/System.map -r
}

#Ending - read the data
getprof () {
TIMES=`/bin/date +%H%M_%S`
echo  "The time is:  $TIMES "
echo  ""
/usr/sbin/readprofile -m /boot/System.map -v | sort -grk3,4 
}

DEFAULT=0   # use this if I do not enter a number
UNAME=`uname -r`
MAP=/boot/System.map-${UNAME}

if [ $# -lt 1 ]
	then

	echo "Collect profile data "
	getprof
	# Turn off collection
	#echo "Turn off collection"
        # echo $DEFAULT > /proc/profile


	else
	SHIFT=$1
 	# turn on collection	
	echo "Turn on readprofiling Profile Shift=${SHIFT} "
	TIMES=`/bin/date +%H%M_%S`
        echo  "The time is:  $TIMES "

        echo ${SHIFT} > /proc/profile

	echo " Clear profile data"
	clearprof
fi
