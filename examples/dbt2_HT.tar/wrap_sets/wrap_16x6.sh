#!/bin/sh
# Change directory to where this script was created so relative path references work

RUNDIR=/home/sapdb/dbt2/scripts
cd $RUNDIR
 
SID=DBT2
TIME=2700
WAREHOUSES=100
DRIVERS=16
SPREAD=6
SWAPPINESS=60
## Plug in system changes here ***************
#sudo bash ./swappiness.sh $SWAPPINESS
#echo "SWAPPINESS SET TO: `cat /proc/sys/vm/swappiness` "
## Plug in database changes here ********************
#cd sapdb
#bash ./start_db.sh
#echo "Return to stock table without s_quantity in the primary key and update stock stats"
#bash ./try_old_stock.sh
##echo "Replacing indexes on orders table"
#date
#echo " Change orders index to iorders2 "
#bash ./change_orders_index.sh
#date
#echo "Update the statstics all tables"
#date
#bash ./update_stats.sh
#date
#echo "Update Optimizer stats for Stock"
#/opt/sapdb/indep_prog/bin/dbmcli -d $SID -u dba,dba -uSQL dbt,dbt sql_execute update statistics stock
#echo "Done"

#echo "Reload the stored procedures"
#date
#bash ./drop_dbproc.sh
#bash ./load_dbproc.sh
#cd ..
#echo "Database changes completed"
#date
##  Database change end here  ***********************


echo "database going offline"
date
cd sapdb
./stop_db.sh
cd -

echo "setting sap db parameters"
_o=`cat <<EOF |  /opt/sapdb/depend/bin/dbmcli -d $SID -u dbm,dbm 2>&1
param_startsession
param_put MAXCPU 8
param_put DATA_CACHE 340000
param_put _MAXTRANS 528
param_put _DELAY_COMMIT YES
param_put _DELAY_LOGWRITER 25
param_put ROLLBACK_CACHE 1000
param_put _USE_IOPROCS_ONLY YES
param_put _DW_IO_AREA_FLUSH 50
param_put _DW_LRU_TAIL_FLUSH 25
param_put XP_MP_RGN_LOOP 0
param_put MAXUSERTASKS 32
param_put _IOPROCS_SWITCH 2
param_put _IOPROCS_PER_DEV 2
param_put LOG_IO_QUEUE 100
param_put _COPY_IO_BLOCK_CNT 4
param_put _MULT_IO_BLOCK_CNT 4
param_put DIAG_HISTORY_NUM 20
param_put _TRANS_RGNS 8 
param_put MAXLOCKS 10000
param_put _LOCK_SUPPLY_BLOCK 100 
param_checkall
param_commitsession
quit
EOF`
_test=`echo $_o | grep ERR`
if ! [ "$_test" = "" ]; then
	echo "set parameters failed: $_o"
	exit 1
fi
RUN_NUMBER=-1
read RUN_NUMBER < .run_number
if [ $RUN_NUMBER -eq -1 ]; then
        RUN_NUMBER=0
fi
mkdir -p output
mkdir -p output/$RUN_NUMBER
OUTPUT_DIR=output/$RUN_NUMBER
./run_test9.sh --duration $TIME --sample 60 --warehouses $WAREHOUSES -ktd 0 -ktn 0 -kto 0 -ktp 0 -kts 0 -ttd 0 -ttn 0 -tto 0 -ttp 0 -tts 0 -tpw 1 --comment "$DRIVERS drivers, $SPREAD warehouses each for new stock-level stored procedure" --drivers $DRIVERS --spread $SPREAD >> $OUTPUT_DIR/status.out

echo "restoring database"
#sapdb/restore_db.sh >> $OUTPUT_DIR/status.out
${RUNDIR}/sapdb/restore_db_in_pieces.sh >> $OUTPUT_DIR/status.out

#echo Loading TABLESTATISTICS and extracting table and sizing information
#cd ./sapdb/db_create_stats
#bash get_it_all.sh > ../../$OUTPUT_DIR/TABLE_SIZING_INFO.txt 2>&1
cd -


