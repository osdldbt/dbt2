#!/bin/sh

SAR=/home/sapdb/sysstat/bin/sar
SAROUTPUT=$1
SAMPLE_LENGTH=$2
OUTPUTDIR=$3
# sar format assumed:
#18:58:42          CPU     %user     %nice   %system   %iowait     %idle

# Prepare processor utilization data.
${SAR} -f $SAROUTPUT -u | grep all | grep -v Average | awk '{ print (NR - 1) * '$SAMPLE_LENGTH', $3 + $4 + $5  }' > $OUTPUTDIR/cpu_all.out
${SAR} -f $SAROUTPUT -u | grep all | grep -v Average | awk '{ print (NR - 1) * '$SAMPLE_LENGTH', $3 }' > $OUTPUTDIR/cpu_user.out
${SAR} -f $SAROUTPUT -u | grep all | grep -v Average | awk '{ print (NR - 1) * '$SAMPLE_LENGTH', $4 }' > $OUTPUTDIR/cpu_nice.out
${SAR} -f $SAROUTPUT -u | grep all | grep -v Average | awk '{ print (NR - 1) * '$SAMPLE_LENGTH', $5 }' > $OUTPUTDIR/cpu_system.out
${SAR} -f $SAROUTPUT -u | grep all | grep -v Average | awk '{ print (NR - 1) * '$SAMPLE_LENGTH', $6 }' > $OUTPUTDIR/cpu_iowait.out
${SAR} -f $SAROUTPUT -u | grep all | grep -v Average | awk '{ print (NR - 1) * '$SAMPLE_LENGTH', $7 }' > $OUTPUTDIR/cpu_idle.out
cd $OUTPUTDIR
gnuplot ../../cpu.input
cd -
