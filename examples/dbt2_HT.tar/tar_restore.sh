echo "cd to scripts directory and remove the next exit statement"
exit
tar xvf /tmp/dbt2_HT.tar  
mkdir output
cd output 
tar xvf /tmp/dbt2_HT_output.tar  

cd --
